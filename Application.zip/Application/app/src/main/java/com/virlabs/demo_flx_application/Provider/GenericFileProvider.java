package com.virlabs.demo_flx_application.Provider;


import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {

}