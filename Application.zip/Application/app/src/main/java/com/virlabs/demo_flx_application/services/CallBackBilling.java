package com.virlabs.demo_flx_application.services;

public interface CallBackBilling {
    void onPurchase();
    void onNotPurchase();
    void onNotLogin();
}
